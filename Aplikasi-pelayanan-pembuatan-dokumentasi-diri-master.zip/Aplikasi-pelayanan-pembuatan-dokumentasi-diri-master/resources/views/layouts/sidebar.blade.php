<section class="sidebar">
      <!-- Sidebar user panel -->
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">

        

        <li class="menu-sidebar"><a href="{{ url('/home') }}"><span class="fa fa-calendar-minus-o"></span> Beranda Dashboard</span></a></li>

        <li class="menu-sidebar"><a href="{{ url('/layanan') }}"><span class="fa fa-calendar-minus-o"></span> Akses Layanan </span></a></li>
        
        <li class="menu-sidebar"><a href="{{ url('/pengajuan') }}"><span class="fa fa-calendar-minus-o"></span> Akses Pengajuan  Layanan </span></a></li>

        <li class="menu-sidebar"><a href="{{ url('/setujui-pengajuan') }}"><span class="fa fa-calendar-minus-o"></span> Akses Status Layanan </span></a></li>
        
        <li class="menu-sidebar"><a href="{{ url('/keluar') }}"><span class="glyphicon glyphicon-log-out"></span> Logout</span></a></li>


      </ul>
    </section>